<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header">Product</div>

                <div class="card-body">
                    <table class="table">
                        <thead class="thead-dark">
                            <tr>
                                <th scope="col">#</th>
                                <th scope="col">Title</th>
                                <th scope="col">Price</th>
                                <th scope="col"></th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $no = 0 ?>
                            <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php $no++ ?>
                            <tr>
                                <th scope="row"><?php echo e($no); ?></th>
                                <td><?php echo e($product->title); ?></td>
                                <td>Rp<?php echo e(number_format($product->price,2,",",".")); ?></td>
                                <td>
                                    <button class="btn btn-sm btn-info text-white">Edit</button>
                                    <button class="btn btn-sm  btn-danger">Delete</button>
                                </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                    <?php echo e($products->Links()); ?>

                </div>
            </div>
        </div>
    </div>
</div>
<?php /**PATH D:\xampp\htdocs\project_shop\sinambela\resources\views/livewire/product/index.blade.php ENDPATH**/ ?>
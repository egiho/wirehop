<?php return array (
  'counter' => 'App\\Http\\Livewire\\Counter',
  'product.index' => 'App\\Http\\Livewire\\Product\\Index',
);
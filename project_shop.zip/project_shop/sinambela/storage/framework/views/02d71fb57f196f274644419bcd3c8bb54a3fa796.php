<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-body">
                   <table class="table">
                    <thead class="thead-dark">
                        <tr>
                            <th>Name</th>
                            <th>Price</th>
                            <th></th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $cart['products']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($product->title); ?></td>
                            <td>Rp<?php echo e(number_format($product->price,2,",",".")); ?></td>
                            <td>
                                <button wire:click="removeFromCart( <?php echo e($product->id); ?> )" class="btn btn-sm btn-danger">Remove</button>
                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                    <tfoot>
                        <tr>
                            <td colspan="3">
                                <a href="<?php echo e(route('shop.checkout')); ?>" class="btn btn-primary float-right">Check Out</a>
                            </td>
                        </tr>
                    </tfoot>
                   </table>
                </div>
            </div>
        </div>
    </div>
</div>
<?php /**PATH D:\xampp\htdocs\project_shop\sinambela\resources\views/livewire/shop/cart.blade.php ENDPATH**/ ?>
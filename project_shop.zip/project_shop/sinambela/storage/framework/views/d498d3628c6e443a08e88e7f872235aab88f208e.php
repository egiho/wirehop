<div>
    <button wire:click="increment">+</button>
    <h1><?php echo e($count); ?></h1>
    <button wire:click="decrement">-</button>
</div>
<?php /**PATH D:\xampp\htdocs\project_shop\sinambela\resources\views/livewire/counter.blade.php ENDPATH**/ ?>
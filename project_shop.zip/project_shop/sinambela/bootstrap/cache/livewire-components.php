<?php return array (
  'product.create' => 'App\\Http\\Livewire\\Product\\Create',
  'product.index' => 'App\\Http\\Livewire\\Product\\Index',
);
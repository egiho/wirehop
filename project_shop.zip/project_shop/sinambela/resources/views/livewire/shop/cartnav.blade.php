<div>
    <li class="nav">
        <a href="{{ route('shop.cart') }}" class="nav-link">Cart ({{ $cartTotal}})</a>
    </li>
</div>
